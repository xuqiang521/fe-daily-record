# 如果 a+b+c=N且 a^2+b^2=c^2（a,b,c 为自然数），如何求出所有a、b、c可能的组合?

# a
# b
# c
# c = 1000-a-b

import time

start_time = time.time()
# for a in range(0, 2001):
#     for b in range(0, 2001):
#         for c in range(0, 2001):
#             if a+b+c==1000 and a**2 + b**2 == c**2:
#                 print("a, b, c:%d, %d, %d" % (a, b, c))
#                 print("a, b, c:%d, %d, %d" % (a, b, c))


# 顺序
# 条件
# 循环


# T = 1000 * 1000 * 1000 * 2
# T = 2000 * 2000 * 2000 * 2
# T = N* N* N*2
#
# T(n) = n^3 * 2
# T(n) = n^3 * 10
#
# T(n) = g(n)
#
# g(n) = n^3


# for a in range(0, n):
#     for b in range(0, n):
#         c = 1000 - a -b
#         if a**2 + b**2 == c**2:
#             print("a, b, c:%d, %d, %d" % (a, b, c))

# T(n) = n * n * (1+ max( 1, 0))
#  = n^2 * 2
#  = O(n^2)


# li = [ 2,3,4,5,6,77, 3,6,3,2,2,1,9,6,0]  n^2
# [1,2,3,4,5,6,7,8]
# for i in li:
#  n

# li[0:3] = [2,3,4,5,6,77]
#
# li = []
# li.append()
# li.insert()
#
# li = [1, 2]
# li*10
# []



 # 每台机器执行的总时间不同
 # 但是执行基本运算数量大体相同

# end_time = time.time()
# print("times:%d" % (end_time-start_time))
# print("finished")
#
#
# name
# age
# hometown
#
# [
#     ("zhangsan", 24, "beijing"),
#     ("zhangsan", 24, "beijing"),
#     ("zhangsan", 24, "beijing"),
# ]
#
# class Stus(object):
#
#     def adds(self)
#     def pop:
#     def sort
#     def modify
#
#
#
#
# for stu in stus:
#     if stu(0)== "zhangsan":
#
# [
#     {
#         "name":"zhangsan",
#         "age":23,
#         "hometown":"beijing"
#     },
# ]
#
# {
#     "zhangsan":{
#         "age":24,
#         "hometown":""
#     },
# }
# stus["zhangsan"]






















